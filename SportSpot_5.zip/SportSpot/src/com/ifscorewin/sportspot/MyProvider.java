package com.ifscorewin.sportspot;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;

public class MyProvider extends ContentProvider {

	public static final String DBNAME = "SportSpotDb";
	private static final String SQL_CREATE_MAIN = "CREATE TABLE Teams ("
			+ "_ID INTEGER PRIMARY KEY, " + "TeamName TEXT, " + "Div TEXT, "
			+ "Sport TEXT, " + "Rank TEXT, " + "PA TEXT, " + "PF TEXT, "
			+ "Win TEXT, " + "Loss TEXT, " + "Tie TEXT, " + "ASP TEXT)";
	public static final Uri CONTENT_URI = Uri
			.parse("content://com.ifscorewin.sportspot.provider");

	protected static final class MainDatabaseHelper extends SQLiteOpenHelper {
		MainDatabaseHelper(Context context) {
			super(context, "SportSpotDb", null, 1);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			db.execSQL(SQL_CREATE_MAIN);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
	        db.execSQL("DROP TABLE IF EXISTS " + "Teams");
	        // Create tables again
	        onCreate(db);
		}
	}

	MainDatabaseHelper mOpenHelper;

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		return mOpenHelper.getWritableDatabase().delete("Teams", selection,
				selectionArgs);
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		String tName = values.getAsString("TeamName");

		long id = mOpenHelper.getWritableDatabase().insert("Teams", null,
				values);
		return Uri.withAppendedPath(CONTENT_URI, "" + id);
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		mOpenHelper = new MainDatabaseHelper(getContext());
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		return mOpenHelper.getReadableDatabase().query("Teams", projection,
				selection, selectionArgs, null, null, sortOrder);
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		return mOpenHelper.getWritableDatabase().update("Teams", values,
				selection, selectionArgs);
	}

}
