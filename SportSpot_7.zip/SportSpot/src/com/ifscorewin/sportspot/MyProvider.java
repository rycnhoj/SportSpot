package com.ifscorewin.sportspot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.content.res.AssetManager;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.util.Log;

public class MyProvider extends ContentProvider {

	private static Context myContext;
	public static final String DBNAME = "SportSpotDb";
	private static final String SQL_CREATE_TEAMS = "CREATE TABLE Teams ("
			+ "_ID INTEGER PRIMARY KEY, " + "TeamName TEXT, " + "Div TEXT, "
			+ "Sport TEXT, " + "Rank TEXT, " + "PA TEXT, " + "PF TEXT, "
			+ "Win TEXT, " + "Loss TEXT, " + "Tie TEXT, " + "ASP TEXT)";

	private static final String SQL_CREATE_SCHEDULES = "CREATE TABLE Schedules ("
			+ "_ID INTEGER PRIMARY KEY, " + "Day TEXT)";

	public static final Uri TEAMS_URI = Uri
			.parse("content://com.ifscorewin.sportspot.provider/teamsUri");
	// "content://com.ifscorewin.sportspot.provider");

	public static final Uri SCHEDULES_URI = Uri
			.parse("content://com.ifscorewin.sportspot.provider/schedulesUri");

	protected static final class MainDatabaseHelper extends SQLiteOpenHelper {
		MainDatabaseHelper(Context context) {
			super(context, "SportSpotDb", null, 1);
			myContext = context;
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			// TODO Auto-generated method stub
			
			db.execSQL(SQL_CREATE_TEAMS);
			db.execSQL(SQL_CREATE_SCHEDULES);

			/* *************************************************************
			 * THIS SECTION LOADS THE DATABASE FROM AN EXTERNAL .CSV FILE
			 * ************************************************************
			 */

			// load data
			AssetManager assetManager = myContext.getAssets();
			try {
				InputStream inputStream = assetManager.open("teams_test.csv");
				InputStreamReader streamReader = new InputStreamReader(
						inputStream);
				BufferedReader bufferedReader = new BufferedReader(streamReader);
				String line;
				String[] values;
				while ((line = bufferedReader.readLine()) != null) {
					values = line.split(",");

					String insertCommand = String
							.format("INSERT INTO Teams(TeamName, Div, Sport, Rank, PA, PF, Win, Loss, Tie, ASP) VALUES(%s, %s, %s, %s, %s, %s, %s, %s, %s, %s)",
									values[0], values[1], values[2], values[3],
									values[4], values[5], values[6], values[7],
									values[8], values[9]);

					db.execSQL(insertCommand);

				}

			} catch (IOException e) {
				Log.e("TBCAE", "Failed to open data input file");
				e.printStackTrace();
			}

		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			// TODO Auto-generated method stub
			db.execSQL("DROP TABLE IF EXISTS " + "Teams");
			db.execSQL("DROP TABLE IF EXISTS " + "Schedules");
			// Create tables again
			onCreate(db);
		}
	}

	MainDatabaseHelper mOpenHelper;

	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		// TODO Auto-generated method stub
		if (uri == TEAMS_URI)
			return mOpenHelper.getWritableDatabase().delete("Teams", selection,
					selectionArgs);
		else if (uri == SCHEDULES_URI)
			return mOpenHelper.getWritableDatabase().delete("Schedules",
					selection, selectionArgs);
		else
			return -1;
	}

	@Override
	public String getType(Uri uri) {
		// TODO Auto-generated method stub
		return null;
	}

	/* ***********************************************************************
	 * THIS SECTION IS NEW
	 * VVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVVV
	 * **********************************************************************
	 */

	@Override
	public Uri insert(Uri uri, ContentValues values) {
		// TODO Auto-generated method stub
		// String tName = values.getAsString("TeamName");

		if (uri == TEAMS_URI) {
			long id = mOpenHelper.getWritableDatabase().insert("Teams", null,
					values);
			return Uri.withAppendedPath(TEAMS_URI, "" + id);
		} else if (uri == SCHEDULES_URI) {
			long id = mOpenHelper.getWritableDatabase().insert("Schedules",
					null, values);
			return Uri.withAppendedPath(SCHEDULES_URI, "" + id);
		} else
			return null;

		/*
		 * Uri _uri = null; switch (uriMatcher.match(uri)){ case TEAMS: long id
		 * = mOpenHelper.getWritableDatabase().insert("Teams", null, values);
		 * //---if added successfully--- return Uri.withAppendedPath(TEAMS_URI,
		 * "" + id); case SCHEDULES: long id2 =
		 * mOpenHelper.getWritableDatabase().insert("Teams", null, values);
		 * //---if added successfully--- return
		 * Uri.withAppendedPath(SCHEDULES_URI, "" + id2); default: throw new
		 * SQLException("Failed to insert row into " + uri); }
		 */
	}

	@Override
	public boolean onCreate() {
		// TODO Auto-generated method stub
		mOpenHelper = new MainDatabaseHelper(getContext());
		return true;
	}

	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		// TODO Auto-generated method stub
		if (uri == TEAMS_URI)
			return mOpenHelper.getReadableDatabase().query("Teams", projection,
					selection, selectionArgs, null, null, sortOrder);
		else if (uri == SCHEDULES_URI)
			return mOpenHelper.getReadableDatabase()
					.query("Schedules", projection, selection, selectionArgs,
							null, null, sortOrder);
		else
			return null;
	}

	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		// TODO Auto-generated method stub
		if (uri == TEAMS_URI)
			return mOpenHelper.getWritableDatabase().update("Teams", values,
					selection, selectionArgs);
		else if (uri == SCHEDULES_URI)
			return mOpenHelper.getWritableDatabase().update("Schedules",
					values, selection, selectionArgs);
		else
			return -1;
	}

}
