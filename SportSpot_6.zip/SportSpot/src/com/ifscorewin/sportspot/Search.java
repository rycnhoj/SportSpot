package com.ifscorewin.sportspot;

import android.app.Activity;
import android.content.ContentValues;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Search extends Activity {

	MyProvider mp;
	EditText nameEditText;
	Button addButton;
	Button goButton;
	Spinner spinner;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.search);

		spinner = (Spinner) findViewById(R.id.sportSpinner);
		// Create an ArrayAdapter using the string array and a default spinner
		// layout
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this, R.array.sports, android.R.layout.simple_spinner_item);
		// Specify the layout to use when the list of choices appears
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// Apply the adapter to the spinner
		spinner.setAdapter(adapter);

		nameEditText = (EditText) findViewById(R.id.searchBar);
		//addButton = (Button) findViewById(R.id.addButton);
		goButton = (Button) findViewById(R.id.goButton);

	}

	public void goClicked(View v) {
		String teamName = nameEditText.getText().toString();
		String sport = spinner.getSelectedItem().toString();
		
		Toast.makeText(this,
				"Searching for " + teamName + "!",
				Toast.LENGTH_LONG).show();
		
	}

	/*public void addClicked(View v) {
		String teamName = nameEditText.getText().toString(); // stores editText
																// value in
																// teamName
		String sport = spinner.getSelectedItem().toString(); // stores sport
																// spinner value
																// in sport
		String friday = "Friday";

		ContentValues values = new ContentValues();
		ContentValues values2 = new ContentValues();
		values.put("Sport", sport);// stores string sport into the "Sport"
									// column in the database
		values.put("TeamName", teamName);// stores string teamName into the
											// "TeamName" column in the database
		values2.put("Day", friday);
		getContentResolver().insert(mp.TEAMS_URI, values);
		getContentResolver().insert(mp.SCHEDULES_URI, values2);
		Toast.makeText(this,
				nameEditText.getText().toString() + " has been added!",
				Toast.LENGTH_LONG).show();
	}*/

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

}
