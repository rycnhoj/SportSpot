package com.ifscorewin.sportspot;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;

public class Splash extends Activity {

	MyProvider mp;
	String[] test = { "test" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);
		Thread logoTimer = new Thread() {
			public void run() {
				
				/*
				 * THE TRY SECTION IS ADDING FLUFF DATA TO THE DATABASE TO
				 * SQLITEOPENHELPER ONCREATE() THEN IT'S DELETING THE FLUFF DATA
				 */
				
				getContentResolver().delete(mp.TEAMS_URI, null, null);
				getContentResolver().delete(mp.SCHEDULES_URI, null, null);
				
				ContentValues values1 = new ContentValues();
				ContentValues values2 = new ContentValues();
				values1.put("TeamName", "test");
				values2.put("Day", "test");
				
				getContentResolver().insert(mp.TEAMS_URI, values1);
				getContentResolver().insert(mp.SCHEDULES_URI, values2);
				getContentResolver().delete(mp.TEAMS_URI,
						"TeamName" + "=?", test);
				getContentResolver().delete(mp.SCHEDULES_URI, "Day" + "=?",
						test);
				
				//ContentValues values1 = new ContentValues();
				//ContentValues values2 = new ContentValues();
				
						
				/* *************************************************************
				 * THIS SECTION LOADS THE DATABASE FROM AN EXTERNAL .CSV FILE
				 * ************************************************************
				 */

				// load data
				AssetManager assetManager = getBaseContext().getAssets();
				try {
					InputStream inputStream = assetManager.open("teams_test.csv");
					InputStreamReader streamReader = new InputStreamReader(
							inputStream);
					BufferedReader bufferedReader = new BufferedReader(streamReader);
					String line;
					String[] values;
					while ((line = bufferedReader.readLine()) != null) {
						values = line.split(",");

						values1.put("TeamName", values[0]);
						values1.put("Div", values[1]);
						values1.put("Sport", values[2]);
						values1.put("Rank", values[3]);
						values1.put("PA", values[4]);
						values1.put("PF", values[5]);
						values1.put("Win", values[6]);
						values1.put("Loss", values[7]);
						values1.put("Tie", values[8]);
						values1.put("ASP", values[9]);

						
						getContentResolver().insert(mp.TEAMS_URI, values1);
						//db.execSQL(insertCommand);

					}

				} catch (IOException e) {
					Log.e("TBCAE", "Failed to open data input file");
					e.printStackTrace();
				}
				
				try {
					Intent searchIntent = new Intent(
							"com.ifscorewin.sportspot.SEARCH");

					sleep(2500);
					startActivity(searchIntent);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					finish();
				}
			}
		};
		logoTimer.start();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.splash, menu);
		return true;
	}

}
