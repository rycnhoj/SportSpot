package com.ifscorewin.sportspot;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.app.Activity;
import android.app.DownloadManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Menu;

public class Splash extends Activity {

	private long enqueue;
	private DownloadManager dm;
	MyProvider mp;
	String[] test = { "test" };
	String[] tba = { "TBA" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);

		/*
		 * 
		 * 
		 * 
		 * http://www.androidsnippets.com/download-an-http-file-to-sdcard-with-
		 * progress-notification
		 * 
		 * http://stackoverflow.com/questions/3551821/android-write-to-sd-card-folder
		 * 
		 * 
		 * 
		 */

		try {
			/*
			 * File sdCard = Environment.getExternalStorageDirectory(); File dir
			 * = new File(sdCard.getAbsolutePath() + "/SportSpot/downloads");
			 * dir.mkdirs();
			 */
			URL u = new URL("http://johncyrav.com/sportspot/teams.csv");
			HttpURLConnection c = (HttpURLConnection) u.openConnection();
			c.setRequestMethod("GET");
			c.setDoOutput(true);
			c.connect();
			File sdCard = Environment.getExternalStorageDirectory();
			File dir = new File(sdCard.getAbsolutePath()
					+ "/SportSpot/downloads");
			dir.mkdirs();
			File file = new File(dir, "teams.csv");

			FileOutputStream f = new FileOutputStream(file);
			// FileOutputStream f = new FileOutputStream(new File(dir,
			// "teams.csv"));

			InputStream in = c.getInputStream();

			byte[] buffer = new byte[1024];
			int len1 = 0;
			while ((len1 = in.read(buffer)) > 0) {
				f.write(buffer, 0, len1);
			}
			f.close();
		} catch (Exception e) {
			Log.d("Downloader", e.getMessage());
		}

		try {
			/*
			 * File sdCard = Environment.getExternalStorageDirectory(); File dir
			 * = new File(sdCard.getAbsolutePath() + "/SportSpot/downloads");
			 * dir.mkdirs();
			 */
			URL u = new URL("http://johncyrav.com/sportspot/schedule.csv");
			HttpURLConnection c = (HttpURLConnection) u.openConnection();
			c.setRequestMethod("GET");
			c.setDoOutput(true);
			c.connect();
			File sdCard = Environment.getExternalStorageDirectory();
			File dir = new File(sdCard.getAbsolutePath()
					+ "/SportSpot/downloads");
			dir.mkdirs();
			File file = new File(dir, "schedule.csv");

			FileOutputStream f = new FileOutputStream(file);
			// FileOutputStream f = new FileOutputStream(new File(dir,
			// "teams.csv"));

			InputStream in = c.getInputStream();

			byte[] buffer = new byte[1024];
			int len1 = 0;
			while ((len1 = in.read(buffer)) > 0) {
				f.write(buffer, 0, len1);
			}
			f.close();
		} catch (Exception e) {
			Log.d("Downloader", e.getMessage());
		}

		/*
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 * 
		 */

		Thread logoTimer = new Thread() {
			public void run() {

				/*
				 * THE TRY SECTION IS ADDING FLUFF DATA TO THE DATABASE TO
				 * SQLITEOPENHELPER ONCREATE() THEN IT'S DELETING THE FLUFF DATA
				 */

				getContentResolver().delete(mp.TEAMS_URI, null, null);
				getContentResolver().delete(mp.SCHEDULES_URI, null, null);

				ContentValues values1 = new ContentValues();
				ContentValues values2 = new ContentValues();
				values1.put("TeamName", "test");
				values2.put("Day", "test");

				getContentResolver().insert(mp.TEAMS_URI, values1);
				getContentResolver().insert(mp.SCHEDULES_URI, values2);
				getContentResolver().delete(mp.TEAMS_URI, "TeamName" + "=?",
						test);
				getContentResolver().delete(mp.TEAMS_URI, "TeamName" + "=?",
						tba);
				getContentResolver().delete(mp.SCHEDULES_URI, "Day" + "=?",
						test);

				// ContentValues values1 = new ContentValues();
				// ContentValues values2 = new ContentValues();

				/* *************************************************************
				 * THIS SECTION LOADS THE DATABASE FROM AN EXTERNAL .CSV FILE
				 * ************************************************************
				 */

				// load data
				AssetManager assetManager = getBaseContext().getAssets();
				try {
					String uri = Environment.getExternalStorageDirectory()
							.toString();
					String teamuri = uri + "/SportSpot/downloads/teams.csv";
					String scheduleuri = uri
							+ "/SportSpot/downloads/schedule.csv";

					/*File file = new File(Environment
							.getExternalStorageDirectory().toString()
							+ "/SportSpot/downloads/teams.csv");*/
					File file = new File(teamuri);
					FileInputStream fileInputStream = new FileInputStream(file);

					
					  //InputStream inputStream = assetManager
					  //.open("teams_test.csv");
					  
					  
					  InputStreamReader streamReader = new InputStreamReader(
					  fileInputStream);//inputStream);
					  
					  
					  BufferedReader bufferedReader = new BufferedReader(
					  streamReader); String line; String[] values; while ((line
					  = bufferedReader.readLine()) != null) { values =
					  line.split(",");
					  
					  values1.put("TeamName", values[0]); values1.put("Div",
					  values[1]); values1.put("Sport", values[2]);
					  values1.put("Rank", values[3]); values1.put("PA",
					  values[4]); values1.put("PF", values[5]);
					  values1.put("Win", values[6]); values1.put("Loss",
					  values[7]); values1.put("Tie", values[8]);
					  values1.put("ASP", values[9]);
					  
					  getContentResolver().insert(mp.TEAMS_URI, values1); //
					  
					  }
					 

				} catch (IOException e) {
					Log.e("TBCAE", "Failed to open data input file");
					e.printStackTrace();
				}

				try {
					Intent searchIntent = new Intent(
							"com.ifscorewin.sportspot.SEARCH");

					sleep(2500);
					startActivity(searchIntent);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} finally {
					finish();
				}
			}
		};
		logoTimer.start();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.splash, menu);
		return true;
	}

}
