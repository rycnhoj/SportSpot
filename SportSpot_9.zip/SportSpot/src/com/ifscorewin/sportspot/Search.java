package com.ifscorewin.sportspot;

import java.util.Locale;

import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

public class Search extends Activity {

	MyProvider mp;
	EditText nameEditText;
	Button addButton;
	Button goButton;
	Spinner spinner;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.search);

		spinner = (Spinner) findViewById(R.id.sportSpinner);
		// Create an ArrayAdapter using the string array and a default spinner
		// layout
		ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
				this, R.array.sports, android.R.layout.simple_spinner_item);
		// Specify the layout to use when the list of choices appears
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		// Apply the adapter to the spinner
		spinner.setAdapter(adapter);

		nameEditText = (EditText) findViewById(R.id.searchBar);
		// addButton = (Button) findViewById(R.id.addButton);
		goButton = (Button) findViewById(R.id.goButton);

	}

	public void goClicked(View v) {
		String teamName = nameEditText.getText().toString();
		String sport = spinner.getSelectedItem().toString();
		String blah = "BLAH";

		/*
		 * NEW SECTION
		 */

		SQLiteDatabase db;

		db = openOrCreateDatabase("SportSpotDb",
				SQLiteDatabase.CREATE_IF_NECESSARY, null);
		db.setVersion(1);
		db.setLocale(Locale.getDefault());

		String[] tableColumns = new String[] { "TeamName" };
		/*String whereClause = "TeamName = ? AND Sport = ?";
		String[] whereArgs = new String[] { '"' + teamName + '"',
				'"' + sport + '"' };*/
		
		String whereClause = "TeamName = ?";
		String[] whereArgs = new String[] { '"' + teamName + '"'};
		
		String orderBy = "TeamName";

		Cursor cur = db.query("Teams", null, whereClause, whereArgs, null,
				null, null);

		if ((cur != null) && (cur.getCount() > 0)) {
			cur.moveToPosition(0);
			blah = cur.getString(2);
			cur.close();
			Toast.makeText(this,
					"The team " + teamName + " is in division " + blah + "!",
					Toast.LENGTH_LONG).show();
		} else {
			Toast.makeText(
					this, "Invalid entry. Please check the spelling and the sport.",
					Toast.LENGTH_LONG).show();
			cur.close();
			return;
		}

		/*
		 * END NEW SECTION
		 */

	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

}
