package com.ifscorewin.sportspot;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

public class home extends Activity{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		ImageButton go = (ImageButton)findViewById(R.id.imageButton1);
		
		go.setOnClickListener(new View.OnClickListener(){
			
			@Override
			public void onClick(View v){
				Log.v("Go!", "Clicked!");
				
				Intent resultsAct = new Intent("android.intent.action.RESULTS");
				startActivity(resultsAct);
			}
			
		});
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	
	
}
