package com.ifscorewin.sportspot;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class results extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.results);
		
		Button mens = (Button)findViewById(R.id.button1);
		Button corec = (Button)findViewById(R.id.button2);
		Button womens = (Button)findViewById(R.id.button3);
		
		mens.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				Log.v("mens", "clicked");
				
				Intent statsAct = new Intent("android.intent.action.STATS");
				startActivity(statsAct);
			}
			
		});
		
		corec.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				Log.v("corec", "clicked");
				
				Intent statsAct = new Intent("android.intent.action.STATS");
				startActivity(statsAct);
			}
			
		});
		
		womens.setOnClickListener(new View.OnClickListener(){

			@Override
			public void onClick(View v) {
				Log.v("womens", "clicked");
				
				Intent statsAct = new Intent("android.intent.action.STATS");
				startActivity(statsAct);
			}
			
		});
	}

	@Override
	protected void onPause() {
		// TODO Auto-generated method stub
		super.onPause();
	}

	
	
}
