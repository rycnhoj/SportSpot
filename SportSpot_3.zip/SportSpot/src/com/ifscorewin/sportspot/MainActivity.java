package com.ifscorewin.sportspot;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;

public class MainActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.splash);
		
		Thread logoTimer = new Thread(){
			public void run(){
				try{
					sleep(2500);
					Intent homeIntent = new Intent("android.intent.action.HOME");
					startActivity(homeIntent);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				finally{
					finish();
				}
			}
		};
		
		logoTimer.start();
	}

}
